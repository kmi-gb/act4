Nombre del Proyecto: Consumo de API con Bootstrap
Descripción: Aplicación web que consume la API de Rick and Morty y muestra personajes con Bootstrap.

URL de la aplicación desplegada: [Aquí coloca la URL después de subirla a GitHub Pages o 000WebHost]

Instrucciones para ejecutar localmente:
1. Descargar el proyecto y descomprimirlo.
2. Abrir el archivo index.html en el navegador.

Autor: [Tu Nombre]
