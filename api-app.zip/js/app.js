document.getElementById("loadCharacters").addEventListener("click", () => {
    fetch("https://rickandmortyapi.com/api/character")
        .then(response => response.json())
        .then(data => {
            let container = document.getElementById("charactersContainer");
            container.innerHTML = "";
            data.results.forEach(character => {
                let card = `
                    <div class="col-md-4">
                        <div class="card mb-3">
                            <img src="${character.image}" class="card-img-top" alt="${character.name}">
                            <div class="card-body">
                                <h5 class="card-title">${character.name}</h5>
                                <p class="card-text">Estado: ${character.status}</p>
                                <p class="card-text">Especie: ${character.species}</p>
                            </div>
                        </div>
                    </div>`;
                container.innerHTML += card;
            });
        })
        .catch(error => console.error("Error al obtener los datos:", error));
});
